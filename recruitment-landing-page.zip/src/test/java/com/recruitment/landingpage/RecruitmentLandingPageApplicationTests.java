package com.recruitment.landingpage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecruitmentLandingPageApplicationTests {

	@Test
	void contextLoads() {
	}

}
