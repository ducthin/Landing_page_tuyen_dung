package com.recruitment.landingpage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecruitmentLandingPageApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecruitmentLandingPageApplication.class, args);
	}

}
